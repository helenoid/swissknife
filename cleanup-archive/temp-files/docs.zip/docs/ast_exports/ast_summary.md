# AST Content Summary
\n## JavaScript/TypeScript ASTs
Files generated: 0
\nSample file listing:
\n## Rust ASTs
Files generated: 50
\nSample file listing:
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-server/src/router.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-server/src/lib.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-server/src/main.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-server/src/errors.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-client/examples/sse.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-client/examples/stdio_integration.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-client/examples/clients.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-client/examples/stdio.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-client/src/service.rs.ast.json
/home/barberb/swissknife/ast_exports/full_asts/rust/crates/mcp-client/src/transport/mod.rs.ast.json
\n## Python ASTs
Files generated: 35
\nSample file listing:
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/diffusion_kit.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/test_fio.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/removebg.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/ipfs_kit.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/test_hf_ipfs.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/hf_instruct_pix2pix.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/ipfs_transformers_generator.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/libp2p_kit.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/ipfs.py.ast.json
/home/barberb/swissknife/ast_exports/full_asts/python/swissknife_old/__init__.py.ast.json
